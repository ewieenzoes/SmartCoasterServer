from django.apps import AppConfig


class UntersetzerbrokerConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'untersetzerBroker'
